<?php 

$x = 'Kelipatan 3 dan 5';
$kel3 = 3;
$kel5 = 5;
switch ($x) {
	case 'Kelipatan 3':
		for($i = 1; $i <= 50; $i++){
			echo $kel3;
			echo " ";
			$kel3 = $kel3 + 3;
			if($kel3 >= 50){
				echo "Foo";
				break;
			}
		}
		break;
	case 'Kelipatan 5':
		for($i = 1; $i <= 50; $i++){
			echo $kel5;
			echo " ";
			$kel5 = $kel5 + 5;
			if($kel5 > 50){
				echo "Bar";
				break;
			}
		}
		break;
	case 'Kelipatan 3 dan 5':
		for($i = 1; $i <= 50; $i++){
			echo $kel3;
			echo " ";
			echo $kel5;
			echo " ";
			$kel3 = $kel3 + 3;
			$kel5 = $kel5 + 5;
			if($kel3 >= 50 && $kel5 > 50){
				echo "FooBar";
				break;
			}
		}
	default:
		# code...
		break;
}

?>