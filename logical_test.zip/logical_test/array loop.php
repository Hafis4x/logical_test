<?php 

$aplikasi = array('gtAkademik', 'gtFinansi', 'gtPerizinan', 'eCampuz', 'eOviz');
$i = 0;
while ($i <= count($aplikasi) - 1) {
	echo $aplikasi[$i];
	echo " ";
	$i++;
}

?>