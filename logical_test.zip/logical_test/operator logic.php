<?php 

$bilangan1 = 7;
$bilangan2 = 2;
for($i = 0; $i <= $bilangan1; $i++){
	$bilangan1 = $bilangan1 - $bilangan2;
	if($bilangan1 < 0){
		break;
	}
}
echo $i;

?>